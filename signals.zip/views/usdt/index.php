<?php

use app\models\Usdt;
use app\models\UsdtSearch;
use yii\data\ActiveDataProvider;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\web\View;
use yii\widgets\ActiveForm;
use yii\widgets\Pjax;

/** @var View $this */
/** @var UsdtSearch $searchModel */
/** @var ActiveDataProvider $dataProvider */
$this->title = 'Usdts';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="usdt-form">

    <?php $form = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-lg-2">

            <?= $form->field($model, 'price')->textInput() ?>
        </div>
        <div class="col-lg-2">
            <?= $form->field($model, 'type')->textInput() ?>
        </div>
        <div class="col-lg-2">

            <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
        </div>
        <div class="col-lg-2">


            <?= $form->field($model, 'phone')->textInput(['maxlength' => true]) ?>
        </div>


        <div class="form-group col-lg-2">
            <?= Html::submitButton('Save', ['class' => 'btn btn-success', 'style' => 'margin-top: 27px;']) ?>
        </div>

        <?php ActiveForm::end(); ?>

    </div>
</div>
<div class="row">

    <div class="col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title mb-0"><?= Html::encode($this->title) ?></h3>
            </div>


            <?php Pjax::begin(); ?>
            <?php // echo $this->render('_search', ['model' => $searchModel]);  ?>

            <div class="card-body">
                <div class="grid-margin">

                    <?=
                    GridView::widget([
                        'dataProvider' => $dataProvider,
                        'filterModel' => $searchModel,
                        'columns' => [
                            ['class' => 'yii\grid\SerialColumn'],
//                            'id',
                            'price',
//                            'date',
                            'type',
//                            'user_id',
                            'name',
                            'phone',
                            [
                                'class' => ActionColumn::className(),
                                'urlCreator' => function ($action, Usdt $model, $key, $index, $column) {
                                    return Url::toRoute([$action, 'id' => $model->id]);
                                }
                            ],
                        ],
                    ]);
                    ?>

                    <?php Pjax::end(); ?>


                </div>
            </div>
        </div>
    </div>
</div>
